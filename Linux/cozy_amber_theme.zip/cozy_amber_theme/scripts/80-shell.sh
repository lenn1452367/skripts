#!/usr/bin/env bash
# Stage 80: Prompt, LS_COLORS, Git-Farben (bash + zsh)
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"

mkdir -p "$COZY_SHELL_DIR"
render "$COZY_ROOT/templates/shell/colors.sh.tpl"        "$COZY_SHELL_DIR/colors.sh"
render "$COZY_ROOT/templates/shell/cozy-amber.bash.tpl"  "$COZY_SHELL_DIR/cozy-amber.bash"
render "$COZY_ROOT/templates/shell/cozy-amber.zsh.tpl"   "$COZY_SHELL_DIR/cozy-amber.zsh"
render "$COZY_ROOT/templates/git/git-colors.gitconfig.tpl" "$COZY_SHELL_DIR/git-colors.gitconfig"

hook() { # <rc-Datei> <Quelldatei>
  local rc="$1" src="$2"
  [[ -f "$rc" ]] || return 0
  backup "$rc"
  grep -q '# >>> cozy-amber >>>' "$rc" && return 0
  printf '\n# >>> cozy-amber >>>\n[ -f "%s" ] && . "%s"\n# <<< cozy-amber <<<\n' "$src" "$src" >> "$rc"
}
hook "$HOME/.bashrc" "$COZY_SHELL_DIR/cozy-amber.bash"
hook "$HOME/.zshrc"  "$COZY_SHELL_DIR/cozy-amber.zsh"
[[ -f "$HOME/.bashrc" ]] || { backup "$HOME/.bashrc"; : > "$HOME/.bashrc"; hook "$HOME/.bashrc" "$COZY_SHELL_DIR/cozy-amber.bash"; }

if have git; then
  git config --global --get-all include.path 2>/dev/null | grep -qxF "$COZY_SHELL_DIR/git-colors.gitconfig" \
    || { backup "$HOME/.gitconfig"; git config --global --add include.path "$COZY_SHELL_DIR/git-colors.gitconfig"; }
fi
ok "Shell-Integration installiert"
