#!/usr/bin/env bash
# Stage 70: xfce4-terminal – 85 % Deckkraft, Block-Cursor, Erdtonpalette
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"
install_rendered terminal/terminalrc.tpl "$CFG_DIR/xfce4/terminal/terminalrc"
ok "Terminal konfiguriert"

# Neuere xfce4-terminal-Versionen (z.B. Linux Mint) lesen zusaetzlich den xfconf-Kanal
XML="$XFCONF_XML_DIR/xfce4-terminal.xml"
if [[ -f "$XML" ]]; then
  backup "$XML"
  pkill -x xfconfd 2>/dev/null || true; sleep 0.5
  python3 "$COZY_ROOT/tools/patch_terminal_xfconf.py" "$CFG_DIR/xfce4/terminal/terminalrc" "$XML"
  warn "Bitte alle offenen Terminal-Fenster schliessen und neu oeffnen (sie schreiben beim Beenden ihre alten Werte zurueck)."
fi
