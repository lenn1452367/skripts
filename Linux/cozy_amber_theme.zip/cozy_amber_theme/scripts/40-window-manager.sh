#!/usr/bin/env bash
# Stage 40: xfwm4-Fensterrahmen (Titelleiste, 8px-Rundung, Drei-Punkte-Knoepfe)
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"
rm -rf "$THEME_DIR/xfwm4"
python3 "$COZY_ROOT/tools/gen_xfwm.py" "$THEME_DIR/xfwm4"
ok "xfwm4-Theme: $THEME_DIR/xfwm4"
