#!/usr/bin/env bash
# Stage 10: Pakete (Xfce-Komponenten, Python-Bildbibliotheken, Schriften, Basis-Icons)
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"

SUDO=""; [[ $EUID -ne 0 ]] && SUDO="sudo"
if   have apt-get; then
  PM=apt; INSTALL="$SUDO apt-get install -y --no-install-recommends"
  PKGS="xfce4-panel xfwm4 xfdesktop4 xfce4-settings thunar xfce4-terminal xfce4-whiskermenu-plugin \
xfce4-pulseaudio-plugin xfce4-power-manager-plugins xfce4-notifyd python3 python3-pil python3-numpy \
fonts-inter fonts-roboto fonts-jetbrains-mono fonts-firacode adwaita-icon-theme libgtk-3-bin \
x11-xserver-utils dbus-x11 fontconfig git"
  $SUDO apt-get update || true
elif have dnf; then
  PM=dnf; INSTALL="$SUDO dnf install -y"
  PKGS="xfce4-panel xfwm4 xfdesktop xfce4-settings Thunar xfce4-terminal xfce4-whiskermenu-plugin \
xfce4-pulseaudio-plugin xfce4-power-manager xfce4-notifyd python3 python3-pillow python3-numpy \
rsms-inter-fonts google-roboto-fonts jetbrains-mono-fonts fira-code-fonts adwaita-icon-theme gtk3 \
xrandr dbus-x11 fontconfig git"
elif have pacman; then
  PM=pacman; INSTALL="$SUDO pacman -S --needed --noconfirm"
  PKGS="xfce4-panel xfwm4 xfdesktop xfce4-settings thunar xfce4-terminal xfce4-whiskermenu-plugin \
xfce4-pulseaudio-plugin xfce4-power-manager xfce4-notifyd python python-pillow python-numpy \
inter-font ttf-roboto ttf-jetbrains-mono ttf-fira-code adwaita-icon-theme gtk3 xorg-xrandr fontconfig git"
elif have zypper; then
  PM=zypper; INSTALL="$SUDO zypper --non-interactive install"
  PKGS="xfce4-panel xfwm4 xfdesktop xfce4-settings thunar xfce4-terminal xfce4-panel-plugin-whiskermenu \
xfce4-panel-plugin-pulseaudio xfce4-power-manager xfce4-notifyd python3 python3-Pillow python3-numpy \
google-roboto-fonts jetbrains-mono-fonts fira-code-fonts adwaita-icon-theme gtk3-tools xrandr git"
else
  warn "Kein unterstuetzter Paketmanager – bitte Abhaengigkeiten manuell installieren (siehe README)."; exit 0
fi

log "Paketmanager: $PM"
for p in $PKGS; do
  $INSTALL "$p" >/dev/null 2>&1 && ok "$p" || warn "Paket nicht installierbar (uebersprungen): $p"
done

python3 -c "import PIL, numpy" 2>/dev/null || die "python3-Module Pillow/numpy fehlen – ohne sie koennen Wallpaper/Icons nicht erzeugt werden"
[[ -d /usr/share/icons/$ICON_BASE_THEME ]] || warn "Basis-Icon-Theme '$ICON_BASE_THEME' fehlt – nur eigene Icons werden erzeugt"
fc-cache -f >/dev/null 2>&1 || true
