#!/usr/bin/env bash
# Stage 30: GTK2/3/4-Theme, settings.ini, libadwaita-Overrides
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"

rm -rf "$THEME_DIR/gtk-2.0" "$THEME_DIR/gtk-3.0"
mkdir -p "$THEME_DIR"
render "$COZY_ROOT/templates/theme/index.theme.tpl"    "$THEME_DIR/index.theme"
render "$COZY_ROOT/templates/gtk-3.0/gtk.css.tpl"      "$THEME_DIR/gtk-3.0/gtk.css"
cp "$THEME_DIR/gtk-3.0/gtk.css"                        "$THEME_DIR/gtk-3.0/gtk-dark.css"
render "$COZY_ROOT/templates/gtk-2.0/gtkrc.tpl"        "$THEME_DIR/gtk-2.0/gtkrc"

install_rendered gtk-4.0/gtk.css.tpl    "$CFG_DIR/gtk-4.0/gtk.css"
install_rendered gtk/settings.ini.tpl   "$CFG_DIR/gtk-3.0/settings.ini"
install_rendered gtk/settings.ini.tpl   "$CFG_DIR/gtk-4.0/settings.ini"
install_rendered gtk/gtkrc-2.0.tpl      "$HOME/.gtkrc-2.0"

if have gsettings; then
  gsettings set org.gnome.desktop.interface gtk-theme   "$GTK_THEME_NAME" 2>/dev/null || true
  gsettings set org.gnome.desktop.interface icon-theme  "$ICON_THEME_NAME" 2>/dev/null || true
  gsettings set org.gnome.desktop.interface color-scheme prefer-dark 2>/dev/null || true
  gsettings set org.gnome.desktop.interface font-name   "$UI_FONT" 2>/dev/null || true
fi
ok "GTK-Theme installiert: $THEME_DIR"
