#!/usr/bin/env bash
# Stage 20: prozedurales Walnuss-Wallpaper mit Warm-Bokeh erzeugen
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"
backup "$WALLPAPER_FILE"
python3 "$COZY_ROOT/tools/gen_wallpaper.py" --out "$WALLPAPER_FILE"
ok "Wallpaper: $WALLPAPER_FILE"
