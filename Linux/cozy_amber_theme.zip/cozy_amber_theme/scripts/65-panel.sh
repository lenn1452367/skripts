#!/usr/bin/env bash
# Stage 65: Panel – oben, 30 px, Glas #2a1b12 @ 75 %, Bernstein-Linie, Plugins
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"
have xfce4-panel || { warn "xfce4-panel fehlt – Stage uebersprungen"; exit 0; }

backup "$XFCONF_XML_DIR/xfce4-panel.xml"
backup "$CFG_DIR/xfce4/panel/whiskermenu-1.rc"
backup "$CFG_DIR/xfce4/panel"

SESSION=0; has_session && SESSION=1
if [[ $SESSION -eq 1 ]]; then
  xfce4-panel --quit >/dev/null 2>&1 || true
  sleep 1
fi
pkill -x xfconfd 2>/dev/null || true   # damit die XML nicht ueberschrieben wird
sleep 0.5

mkdir -p "$XFCONF_XML_DIR" "$CFG_DIR/xfce4/panel"
render "$COZY_ROOT/templates/panel/xfce4-panel.xml.tpl" "$XFCONF_XML_DIR/xfce4-panel.xml"
render "$COZY_ROOT/templates/panel/whiskermenu.rc.tpl"  "$CFG_DIR/xfce4/panel/whiskermenu-1.rc"

if [[ $SESSION -eq 1 ]]; then
  (nohup xfce4-panel --disable-wm-check >/dev/null 2>&1 &) || true
fi
ok "Panel konfiguriert"
