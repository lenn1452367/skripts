#!/usr/bin/env bash
# Stage 50: Icon-Theme (Basis umgefaerbt + Terracotta/Bernstein-Ordner + Startmenue-Icon)
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"
python3 "$COZY_ROOT/tools/build_icons.py" "$ICON_DIR"
have gtk-update-icon-cache && gtk-update-icon-cache -f -t "$ICON_DIR" >/dev/null 2>&1 || warn "Icon-Cache nicht aktualisiert"
ok "Icon-Theme: $ICON_DIR"
