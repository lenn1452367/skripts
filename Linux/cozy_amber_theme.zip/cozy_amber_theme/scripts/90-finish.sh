#!/usr/bin/env bash
# Stage 90: Theme live neu laden und Abschlusspruefung
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"

if has_session; then
  # Toggle, damit xfwm4/GTK neu erzeugte Theme-Dateien sicher neu einlesen
  xf_set xfwm4     /general/theme   string Default;  sleep 0.4
  xf_set xfwm4     /general/theme   string "$GTK_THEME_NAME"
  xf_set xsettings /Net/ThemeName   string Adwaita;  sleep 0.4
  xf_set xsettings /Net/ThemeName   string "$GTK_THEME_NAME"
  xf_set xsettings /Net/IconThemeName string hicolor; sleep 0.4
  xf_set xsettings /Net/IconThemeName string "$ICON_THEME_NAME"
  xfdesktop --reload >/dev/null 2>&1 || true
else
  warn "Keine laufende Sitzung – Einstellungen greifen beim naechsten Login."
fi
bash "$COZY_ROOT/verify.sh" || warn "verify.sh meldet Abweichungen (siehe oben)"
