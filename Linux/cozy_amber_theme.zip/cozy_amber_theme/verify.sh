#!/usr/bin/env bash
# Abschliessende Pruefkriterien: kein kalter Blau-/Grau-/Neonton + Soll-Werte.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$ROOT/lib/common.sh"
FAIL=0
chk() { if eval "$2"; then ok "$1"; else warn "FEHLT/FALSCH: $1"; FAIL=1; fi; }

log "Dateien"
chk "GTK3-Theme"        "[[ -f $THEME_DIR/gtk-3.0/gtk.css ]]"
chk "xfwm4-Theme"       "[[ -f $THEME_DIR/xfwm4/themerc && -f $THEME_DIR/xfwm4/close-active.png ]]"
chk "Icon-Theme"        "[[ -f $ICON_DIR/index.theme && -f $ICON_DIR/cozy/places/folder.svg ]]"
chk "Wallpaper"         "[[ -f $WALLPAPER_FILE ]]"
chk "Terminal-Konfig"   "grep -q 'BackgroundDarkness=$TERMINAL_OPACITY' $CFG_DIR/xfce4/terminal/terminalrc"
chk "Panel-Konfig"      "grep -q 'background-style' $XFCONF_XML_DIR/xfce4-panel.xml"
chk "Shell-Integration" "[[ -f $COZY_SHELL_DIR/cozy-amber.bash ]]"

log "Farb-Audit (kein Blau / Grau / Neon)"
python3 "$ROOT/tools/audit_colors.py" "$THEME_DIR" "$ICON_DIR" "$WALLPAPER_FILE" \
  "$CFG_DIR/xfce4/terminal" "$XFCONF_XML_DIR" "$COZY_SHELL_DIR" "$CFG_DIR/gtk-3.0" "$CFG_DIR/gtk-4.0" || FAIL=1

if has_session; then
  log "Live-Einstellungen (xfconf)"
  chk "GTK-Theme aktiv"      "[[ \$(xfq -c xsettings -p /Net/ThemeName 2>/dev/null) == $GTK_THEME_NAME ]]"
  chk "Icon-Theme aktiv"     "[[ \$(xfq -c xsettings -p /Net/IconThemeName 2>/dev/null) == $ICON_THEME_NAME ]]"
  chk "xfwm4-Theme aktiv"    "[[ \$(xfq -c xfwm4 -p /general/theme 2>/dev/null) == $GTK_THEME_NAME ]]"
  chk "Compositor an"        "[[ \$(xfq -c xfwm4 -p /general/use_compositing 2>/dev/null) == true ]]"
  chk "Kein picom aktiv"     "! pgrep -x picom >/dev/null"
fi
[[ $FAIL -eq 0 ]] && ok "Alle Pruefkriterien erfuellt." || { warn "Pruefung hat Abweichungen ergeben."; exit 1; }
