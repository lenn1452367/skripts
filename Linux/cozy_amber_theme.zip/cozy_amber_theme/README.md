# Cozy Amber & Frosted Glass – Xfce-Systemdesign

Setzt die Ziel-Spezifikation (`LinuxWoodGlassDesign.txt`) vollautomatisch um.
Alle Farben stehen **nur** in `config/palette.conf`; alle Maße/Werte in `config/settings.conf`.

```
./install.sh            # alles einrichten (legt Backup des Originalzustands an)
./verify.sh             # Abschluss-Prüfkriterien + Farb-Audit
./uninstall.sh          # Originalzustand wiederherstellen
./install.sh --skip-deps            # ohne Paketinstallation
./install.sh --only "30 50"         # nur bestimmte Stages
```

## Aufbau

| Pfad | Zweck (Spezifikation) |
|---|---|
| `config/palette.conf` | Alle Farbwerte (#1e130c, #2a1b12, #e88d4f, #f2e8cf, #b8a892, #d4a359, …) |
| `config/settings.conf` | Radius 8 px, Schatten, Panel 30 px / 75 %, Terminal 85 %, Fade 150 ms, Schriften |
| `lib/common.sh` | Backup, xfconf-Helfer, Schriftauswahl (Inter/Roboto, JetBrains Mono/Fira Code) |
| `scripts/10-dependencies.sh` | Pakete (apt/dnf/pacman/zypper) |
| `scripts/20-wallpaper.sh` | §2 Walnuss-Wallpaper + weiches Warm-Bokeh (`tools/gen_wallpaper.py`) |
| `scripts/30-gtk-theme.sh` | §4 GTK2/3/4-Theme: Rundung, Schatten, Auswahl #5e3821 + Bernstein-Rand, §6 Hover-Fade |
| `scripts/40-window-manager.sh` | §4 xfwm4-Rahmen: #2a1b12, Drei-Punkte-Knöpfe ohne Symbole (`tools/gen_xfwm.py`) |
| `scripts/50-icons.sh` | §4 Icon-Theme: Adwaita komplett umgefärbt + Terracotta/Bernstein-Ordner (`tools/build_icons.py`) |
| `scripts/60-xfconf.sh` | Themes, Fonts, nativer xfwm4-Compositor (kein picom), Wallpaper auf allen Monitoren |
| `scripts/65-panel.sh` | §3 Panel oben, Glas-RGBA 75 %, 1-px-Bernsteinlinie, Start-Icon/Uhr/Tray |
| `scripts/70-terminal.sh` | §5 xfce4-terminal: 85 % Deckkraft, Block-Cursor, Erdtonpalette |
| `scripts/80-shell.sh` | §5 Prompt, `LS_COLORS`, Git-Farben (bash + zsh) |
| `scripts/90-finish.sh` | Live-Reload + `verify.sh` |
| `tools/audit_colors.py` | Prüft, dass kein kühler Blau-/Grau-/Neonton vorkommt |
| `templates/` | Alle Konfigurationsdateien mit `{{PLATZHALTERN}}` |

## Hinweise
* Transparenz ausschließlich über RGBA und den xfwm4-Compositor – kein Blur, kein picom.
* Backup: Jede berührte Datei wird beim ersten Lauf nach `~/.local/share/cozy-amber/original-backup` gesichert.
* Bekannte Grenzen: Der Mauszeiger-Cursor ist nicht umgefärbt (Cursor-Theme); das Pulsieren des
  Terminal-Cursors ist ein langsames Blinken (VTE kennt keine weiche Animation); die Uhr ist
  mittig zwischen Start-Icon und Tray – bei sehr ungleich breiten Seiten leicht versetzt.
* Fensterrahmen/Panel konnten nur generiert und per Audit geprüft werden; das Aussehen auf dem
  echten Desktop bitte einmal ansehen und ggf. in `config/settings.conf` nachjustieren.
