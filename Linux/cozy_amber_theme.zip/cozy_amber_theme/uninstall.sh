#!/usr/bin/env bash
# Stellt den Originalzustand wieder her und entfernt alles Installierte.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$ROOT/lib/common.sh"

has_session && { xfce4-panel --quit 2>/dev/null || true; }
pkill -x xfconfd 2>/dev/null || true

if [[ -f "$BACKUP_DIR/MANIFEST" ]]; then
  while read -r kind rel; do
    case "$kind" in
      M) rm -rf "${HOME:?}/$rel"; mkdir -p "$(dirname "$HOME/$rel")"; cp -a "$BACKUP_DIR/files/$rel" "$HOME/$rel" ;;
      C) rm -rf "${HOME:?}/$rel" ;;
    esac
  done < "$BACKUP_DIR/MANIFEST"
  ok "Originaldateien wiederhergestellt"
else
  warn "Kein Backup gefunden – entferne nur installierte Verzeichnisse"
fi

rm -rf "$THEME_DIR" "$ICON_DIR" "$COZY_SHELL_DIR" "$WALLPAPER_FILE"
for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
  [[ -f "$rc" ]] && sed -i '/# >>> cozy-amber >>>/,/# <<< cozy-amber <<</d' "$rc"
done
if have git; then git config --global --unset-all include.path 'cozy-amber' 2>/dev/null || true; fi
rm -rf "$STATE_DIR"

if has_session; then
  (nohup xfce4-panel --disable-wm-check >/dev/null 2>&1 &) || true
  xfdesktop --reload 2>/dev/null || true
fi
ok "Deinstalliert."
