#!/usr/bin/env bash
# Cozy Amber & Frosted Glass – Orchestrator
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
. "$ROOT/lib/common.sh"

SKIP_DEPS=0; ONLY=""
usage() { cat <<U
Aufruf: ./install.sh [--skip-deps] [--only "20 30 ..."] [-h]
  --skip-deps   Paketinstallation (Stage 10) ueberspringen
  --only LISTE  nur diese Stage-Nummern ausfuehren (z.B. --only "30 50")
Stages: $(ls "$ROOT"/scripts | sed 's/\.sh$//' | tr '\n' ' ')
U
}
while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-deps) SKIP_DEPS=1 ;;
    --only) ONLY="$2"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) usage; exit 1 ;;
  esac; shift
done

have python3 || die "python3 wird benoetigt"
log "Cozy Amber & Frosted Glass wird eingerichtet (Backup nach $BACKUP_DIR)"
for s in "$ROOT"/scripts/[0-9][0-9]-*.sh; do
  base="$(basename "$s")"; num="${base%%-*}"
  [[ $SKIP_DEPS -eq 1 && "$num" == "10" ]] && continue
  if [[ -n "$ONLY" && " $ONLY " != *" $num "* ]]; then continue; fi
  log "Stage $base"
  bash "$s"
done
ok "Fertig. Abmelden/Anmelden empfohlen. Pruefen mit: ./verify.sh"
