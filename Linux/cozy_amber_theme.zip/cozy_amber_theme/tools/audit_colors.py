#!/usr/bin/env python3
"""Abschlusspruefung: findet kuehle Blau-/Gruen-/Violett-Toene, Neutralgrau und Reinweiss.
Erlaubt sind exakt die Farben aus config/palette.conf (z.B. Waldgruen des Maximieren-Knopfs)."""
import colorsys, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from render import load_conf, ROOT

ALLOW = {v.lower() for v in load_conf(os.path.join(ROOT, "config", "palette.conf")).values()
         if re.fullmatch(r"#[0-9a-fA-F]{6}", v)}
HEX = re.compile(r'(?<!url\()(?<!href=")(?<![\w&])#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3})(?![0-9a-zA-Z_-])')
RGBF = re.compile(r'rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)')
TEXT_EXT = {".css", ".svg", ".rc", ".conf", ".ini", ".xml", ".sh", ".bash", ".zsh", ".gitconfig", ".theme"}
TEXT_NAMES = {"gtkrc", "themerc", "terminalrc", "gtkrc-2.0", "index.theme"}

def classify(r, g, b):
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    if v < .12:                       # Schwarz-Schatten sind erlaubt
        return None
    if s < .10:
        return "neutral (grau/weiss)"
    if s >= .12 and 105 <= h * 360 <= 345:
        return f"kalt (Hue {h*360:.0f}°)"
    return None

def check_hex(h):
    h = h.lower()
    if len(h) == 3: h = "".join(ch * 2 for ch in h)
    if len(h) == 8: h = h[:6]
    if "#" + h in ALLOW: return None
    return classify(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))

def scan_text(path, bad):
    try:
        if os.path.getsize(path) > 3_000_000: return
        with open(path, encoding="utf-8") as fh: text = fh.read()
    except (UnicodeDecodeError, OSError):
        return
    for m in HEX.finditer(text):
        why = check_hex(m.group(1))
        if why: bad.append((path, "#" + m.group(1), why))
    for m in RGBF.finditer(text):
        r, g, b = map(int, m.groups())
        if (r, g, b) == (0, 0, 0): continue
        why = classify(r, g, b)
        if why: bad.append((path, m.group(0) + ")", why))

def scan_image(path, bad, limit=.005):
    # Der Maximieren-Knopf ist laut Spezifikation Waldgruen (#5b8258) -> gewollte Ausnahme
    if os.path.basename(path).startswith("maximize"):
        return
    try:
        from PIL import Image
        import numpy as np
    except ImportError:
        print("  (Pillow/numpy fehlen – Bildpruefung uebersprungen)"); return
    im = Image.open(path).convert("RGBA")
    a = np.asarray(im)[::4, ::4].reshape(-1, 4).astype(np.float32) / 255
    a = a[a[:, 3] > .5][:, :3]
    if not len(a): return
    mx, mn = a.max(1), a.min(1)
    v, s = mx, np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-6), 0)
    d = np.maximum(mx - mn, 1e-6)
    h = np.where(mx == a[:, 0], ((a[:, 1] - a[:, 2]) / d) % 6,
        np.where(mx == a[:, 1], (a[:, 2] - a[:, 0]) / d + 2, (a[:, 0] - a[:, 1]) / d + 4)) * 60
    cool = (v >= .12) & (((s >= .12) & (h >= 105) & (h <= 345)) | (s < .10))
    frac = float(cool.mean())
    if frac > limit: bad.append((path, f"{frac*100:.2f}% kalte/graue Pixel", "Bild"))

def main(paths):
    bad, n = [], 0
    for p in paths:
        if not os.path.exists(p): continue
        if os.path.isfile(p): files = [p]
        else: files = [os.path.join(d, f) for d, _, fs in os.walk(p) for f in fs]
        for f in files:
            ext = os.path.splitext(f)[1].lower(); name = os.path.basename(f)
            if ext in TEXT_EXT or name in TEXT_NAMES: scan_text(f, bad); n += 1
            elif ext in (".png",) and ("xfwm4" in f or "backgrounds" in f or "walnut" in f):
                scan_image(f, bad); n += 1
    for path, col, why in bad[:40]:
        print(f"  ✗ {path}: {col} -> {why}")
    if len(bad) > 40: print(f"  … und {len(bad)-40} weitere")
    print(f"  {n} Dateien geprueft, {len(bad)} Verstoesse")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
