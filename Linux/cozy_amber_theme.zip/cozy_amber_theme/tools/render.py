#!/usr/bin/env python3
"""Template-Renderer: ersetzt {{KEY}} aus palette.conf + settings.conf + Umgebung.
Fuer jede Farbe #rrggbb entstehen zusaetzlich KEY_R/_G/_B (0-255), KEY_RF/_GF/_BF (0-1)
und KEY_RGB ("r, g, b")."""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load_conf(path):
    d = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            v = v.strip()
            if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
                v = v[1:-1]
            d[k.strip()] = v
    return d

def context():
    ctx = {}
    for f in ("palette.conf", "settings.conf"):
        ctx.update(load_conf(os.path.join(ROOT, "config", f)))
    ctx.update(os.environ)
    for k, v in list(ctx.items()):
        if re.fullmatch(r"#[0-9a-fA-F]{6}", v):
            r, g, b = (int(v[i:i + 2], 16) for i in (1, 3, 5))
            ctx.update({k + "_R": str(r), k + "_G": str(g), k + "_B": str(b),
                        k + "_RF": f"{r/255:.6f}", k + "_GF": f"{g/255:.6f}", k + "_BF": f"{b/255:.6f}",
                        k + "_RGB": f"{r}, {g}, {b}"})
    return ctx

PAT = re.compile(r"\{\{([A-Z][A-Z0-9_]*)\}\}")

def render_text(text, ctx, src="<text>"):
    missing = set()
    def sub(m):
        k = m.group(1)
        if k not in ctx:
            missing.add(k)
            return m.group(0)
        return ctx[k]
    out = PAT.sub(sub, text)
    if missing:
        sys.exit(f"render.py: unbekannte Platzhalter in {src}: {', '.join(sorted(missing))}")
    return out

if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: render.py <template> <output>")
    src, dst = sys.argv[1], sys.argv[2]
    with open(src, encoding="utf-8") as fh:
        text = fh.read()
    out = render_text(text, context(), src)
    os.makedirs(os.path.dirname(os.path.abspath(dst)), exist_ok=True)
    with open(dst, "w", encoding="utf-8") as fh:
        fh.write(out)
