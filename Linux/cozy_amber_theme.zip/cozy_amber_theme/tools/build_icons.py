#!/usr/bin/env python3
"""Baut das Icon-Theme 'CozyAmber':
 1. Basis-Theme (Adwaita) 1:1 kopieren und ALLE Farben in Erd-/Amberton umrechnen
 2. eigene Terracotta/Bernstein-Ordner, Papierkorb und das Startmenue-Icon hinzufuegen
 3. index.theme patchen (eigene Icons haben Vorrang)"""
import colorsys, math, os, re, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from render import context

ctx = context()
DEST = sys.argv[1]
BASE = ctx.get("ICON_BASE_THEME", "Adwaita")
NAME = ctx["ICON_THEME_NAME"]

# ------------------------------------------------------------------ Farb-Umrechnung
def warm(r, g, b):
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    if s < .10:                                   # Neutralgrau/Weiss -> warmer Sand/Creme
        nh = 32
        if l > .8: ns, nl = .85, min(l, .91)
        else:      ns, nl = .28, l
    else:                                         # alle Buntfarben -> Amber-Spektrum 14°..42°
        nh = 28 + 14 * math.sin(math.radians(h * 360))
        ns, nl = min(.78, .25 + s * .55), min(l, .92)
    if nl > .8:                                   # helle Flaechen immer sichtbar cremig (nie Reinweiss/Grau)
        ns, nl = max(ns, .85), min(nl, .91)
    rr, gg, bb = colorsys.hls_to_rgb(nh / 360, nl, ns)
    return round(rr * 255), round(gg * 255), round(bb * 255)

HEX = re.compile(r'(?<!url\()(?<!href=")(?<![\w&])#([0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3})(?![0-9a-zA-Z_-])')
RGBF = re.compile(r'rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)')
NAMED = re.compile(r'(fill|stroke|stop-color|flood-color|color)(=|:)\s*"?\s*(white|black|gray|grey)\b"?')
NAMED_MAP = {"white": (242, 232, 207), "black": (30, 19, 12), "gray": (184, 168, 146), "grey": (184, 168, 146)}

def recolor_svg(text):
    def hx(m):
        h = m.group(1)
        if len(h) == 3: h = "".join(c * 2 for c in h)
        alpha = h[6:]
        r, g, b = warm(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
        return f"#{r:02x}{g:02x}{b:02x}{alpha}"
    text = HEX.sub(hx, text)
    text = RGBF.sub(lambda m: "rgb(%d,%d,%d)" % warm(*map(int, m.groups())), text)
    def nm(m):
        r, g, b = NAMED_MAP[m.group(3)]
        q = '"' if '"' in m.group(0) else ""
        return f"{m.group(1)}{m.group(2)}{q}#{r:02x}{g:02x}{b:02x}{q}"
    return NAMED.sub(nm, text)

def recolor_png(src, dst):
    try:
        from PIL import Image
        import numpy as np
    except ImportError:
        shutil.copy2(src, dst); return
    im = Image.open(src).convert("RGBA")
    a = np.asarray(im).astype(np.float32)
    lum = (a[..., 0] * .299 + a[..., 1] * .587 + a[..., 2] * .114) / 255
    stops = [0, .45, .75, 1]
    ramp = np.array([(30, 19, 12), (184, 111, 80), (232, 141, 79), (242, 232, 207)], np.float32)
    for c in range(3):
        a[..., c] = np.interp(lum, stops, ramp[:, c])
    Image.fromarray(a.astype(np.uint8), "RGBA").save(dst)

def copy_recolored(base, dest):
    n = 0
    for d, dirs, files in os.walk(base):
        rel = os.path.relpath(d, base)
        os.makedirs(os.path.join(dest, rel), exist_ok=True)
        for f in files:
            s, t = os.path.join(d, f), os.path.join(dest, rel, f)
            if os.path.islink(s):
                if os.path.lexists(t): os.remove(t)
                os.symlink(os.readlink(s), t)
            elif f.endswith(".svg"):
                with open(s, encoding="utf-8", errors="ignore") as fh: txt = fh.read()
                with open(t, "w", encoding="utf-8") as fh: fh.write(recolor_svg(txt))
                n += 1
            elif f.endswith(".png") and not f.endswith(".symbolic.png"):
                recolor_png(s, t); n += 1
            elif f != "index.theme" and not f.endswith((".cache",)):
                shutil.copy2(s, t)
    return n

# ------------------------------------------------------------------ eigene Icons
C = {k: ctx[k] for k in ("FOLDER_BACK", "FOLDER_FRONT_TOP", "FOLDER_FRONT_BOTTOM", "BG_BAR", "BG_DEEP", "FG", "ICON_GOLD")}
GLYPH = f'fill="{C["BG_BAR"]}" fill-opacity=".8"'
LINE = f'fill="{C["FG"]}"'

def folder(glyph="", opened=False):
    front = ('<path d="M4 56 L11 25 Q12 22 15 22 H63 Q64.5 22 64 24 L57.5 53 Q56.5 56 53 56 Z" fill="url(#f)"/>'
             if opened else '<rect x="6" y="21" width="52" height="35" rx="4" fill="url(#f)"/>')
    shine = f'<rect x="8" y="22" width="48" height="1.6" rx=".8" fill="{C["FG"]}" fill-opacity=".28"/>' if not opened else ""
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
<defs><linearGradient id="f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{C["FOLDER_FRONT_TOP"]}"/><stop offset="1" stop-color="{C["FOLDER_FRONT_BOTTOM"]}"/></linearGradient></defs>
<ellipse cx="32" cy="58.5" rx="24" ry="2.4" fill="{C["BG_DEEP"]}" fill-opacity=".35"/>
<path d="M6 14a4 4 0 0 1 4-4h14.5a4 4 0 0 1 2.8 1.2L31 15h23a4 4 0 0 1 4 4v33a4 4 0 0 1-4 4H10a4 4 0 0 1-4-4z" fill="{C["FOLDER_BACK"]}"/>
{front}{shine}
<g {GLYPH}>{glyph}</g></svg>'''

GLYPHS = {
 "documents": f'<rect x="24" y="27" width="16" height="21" rx="2"/><g {LINE}><rect x="27" y="32" width="10" height="1.8" rx=".9"/><rect x="27" y="36" width="10" height="1.8" rx=".9"/><rect x="27" y="40" width="6" height="1.8" rx=".9"/></g>',
 "download":  '<path d="M29 27h6v9h5l-8 9-8-9h5z"/><rect x="23" y="47" width="18" height="3" rx="1.5"/>',
 "pictures":  '<path d="M21 48l8-11 5 6 4-5 9 10z"/><circle cx="41" cy="31" r="3.2"/>',
 "music":     '<circle cx="28" cy="44" r="4.2"/><circle cx="40" cy="41" r="4.2"/><path d="M31.4 44V29l12-3.2v15h-3.2V30.4l-5.6 1.5V44z"/>',
 "videos":    '<path d="M27 28l17 9.5L27 47z"/>',
 "publicshare": '<circle cx="40" cy="30" r="4"/><circle cx="25" cy="38" r="4"/><circle cx="40" cy="46" r="4"/><path d="M25 38l15-8M25 38l15 8" stroke="%s" stroke-opacity=".8" stroke-width="2" fill="none"/>' % C["BG_BAR"],
 "templates": '<rect x="23" y="27" width="18" height="21" rx="2" fill="none" stroke="%s" stroke-opacity=".8" stroke-width="2" stroke-dasharray="3 2"/><rect x="27" y="33" width="10" height="2" rx="1"/><rect x="27" y="38" width="10" height="2" rx="1"/>' % C["BG_BAR"],
 "home":      '<path d="M32 26l-12 10h3.5v11h17V36H44z"/>',
 "desktop":   '<rect x="21" y="28" width="22" height="14" rx="2"/><rect x="29" y="43" width="6" height="3"/><rect x="25" y="46" width="14" height="2.4" rx="1.2"/>',
 "remote":    '<circle cx="32" cy="38" r="9.5" fill="none" stroke="%s" stroke-opacity=".8" stroke-width="2"/><path d="M22.5 38h19M32 28.5c-4 4.5-4 14.5 0 19M32 28.5c4 4.5 4 14.5 0 19" stroke="%s" stroke-opacity=".8" stroke-width="1.8" fill="none"/>' % (C["BG_BAR"], C["BG_BAR"]),
}

def trash(full):
    paper = f'<path d="M19 22l7-7 6 5 6-6 7 8z" fill="{C["FG"]}" fill-opacity=".9"/>' if full else ""
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
<defs><linearGradient id="f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{C["FOLDER_FRONT_TOP"]}"/><stop offset="1" stop-color="{C["FOLDER_FRONT_BOTTOM"]}"/></linearGradient></defs>
<ellipse cx="32" cy="58.5" rx="19" ry="2.2" fill="{C["BG_DEEP"]}" fill-opacity=".35"/>{paper}
<rect x="25" y="8" width="14" height="6" rx="2.5" fill="{C["FOLDER_BACK"]}"/>
<path d="M15 23h34l-3 31.5a4 4 0 0 1-4 3.5H22a4 4 0 0 1-4-3.5z" fill="url(#f)"/>
<rect x="11" y="15" width="42" height="7" rx="3.5" fill="{C["FOLDER_BACK"]}"/>
<g {GLYPH}><rect x="24" y="28" width="3" height="24" rx="1.5"/><rect x="30.5" y="28" width="3" height="24" rx="1.5"/><rect x="37" y="28" width="3" height="24" rx="1.5"/></g></svg>'''

START = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16">
<g fill="{ctx["FG"]}"><rect x="1.5" y="1.5" width="5.5" height="5.5" rx="1.5"/><rect x="9" y="1.5" width="5.5" height="5.5" rx="1.5"/>
<rect x="1.5" y="9" width="5.5" height="5.5" rx="1.5"/><rect x="9" y="9" width="5.5" height="5.5" rx="1.5"/></g></svg>'''

def write(rel, text):
    p = os.path.join(DEST, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh: fh.write(text)

def custom_icons():
    plain = folder()
    for n in ("folder", "inode-directory", "folder-saved-search"): write(f"cozy/places/{n}.svg", plain)
    for n in ("folder-open", "folder-drag-accept", "folder-visiting"): write(f"cozy/places/{n}.svg", folder(opened=True))
    m = {"folder-documents": "documents", "folder-download": "download", "folder-pictures": "pictures",
         "folder-music": "music", "folder-videos": "videos", "folder-publicshare": "publicshare",
         "folder-templates": "templates", "user-home": "home", "user-desktop": "desktop", "folder-remote": "remote"}
    for n, g in m.items(): write(f"cozy/places/{n}.svg", folder(GLYPHS[g]))
    write("cozy/places/user-trash.svg", trash(False)); write("cozy/places/user-trash-full.svg", trash(True))
    write("cozy/apps/cozy-start.svg", START)

SECTIONS = "".join(f"\n[cozy/{d}]\nSize=64\nMinSize=16\nMaxSize=512\nContext={c}\nType=Scalable\n"
                   for d, c in (("places", "Places"), ("apps", "Applications")))

def write_index(base_index):
    dirs = ["cozy/places", "cozy/apps"]
    if base_index and os.path.exists(base_index):
        out, main = [], False
        for ln in open(base_index, encoding="utf-8", errors="ignore").read().splitlines():
            s = ln.strip()
            if s.startswith("["): main = (s == "[Icon Theme]")
            if main:
                if s.startswith(("Name[", "Comment[", "Example=", "Hidden=")): continue
                if s.startswith("Name="): ln = f"Name={NAME}"
                elif s.startswith("Comment="): ln = "Comment=Cozy Amber warm earth-tone icons"
                elif s.startswith("Inherits="): ln = "Inherits=hicolor"
                elif s.startswith("Directories="): ln = "Directories=" + ",".join(dirs) + "," + s.split("=", 1)[1]
            out.append(ln)
        text = "\n".join(out) + "\n" + SECTIONS
        if "Inherits=" not in text: text = text.replace("[Icon Theme]", "[Icon Theme]\nInherits=hicolor", 1)
    else:
        text = f"[Icon Theme]\nName={NAME}\nComment=Cozy Amber icons\nInherits=hicolor\nDirectories={','.join(dirs)}\n" + SECTIONS
    write("index.theme", text)

def find_base():
    for p in (f"/usr/share/icons/{BASE}", f"/usr/local/share/icons/{BASE}",
              os.path.expanduser(f"~/.local/share/icons/{BASE}")):
        if os.path.isdir(p): return p
    return None

if __name__ == "__main__":
    if os.path.isdir(DEST): shutil.rmtree(DEST)
    os.makedirs(DEST)
    base = find_base()
    if base:
        print(f"Basis-Theme {base}: recolor …")
        print(f"  {copy_recolored(base, DEST)} Icons umgefaerbt")
    else:
        print(f"WARNUNG: Basis-Theme '{BASE}' nicht gefunden – nur eigene Icons (Rest erbt von hicolor)", file=sys.stderr)
    custom_icons()
    write_index(os.path.join(base, "index.theme") if base else None)
    print(f"Icon-Theme: {DEST}")
