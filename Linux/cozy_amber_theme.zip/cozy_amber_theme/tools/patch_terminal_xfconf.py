#!/usr/bin/env python3
"""Uebertraegt die Werte aus terminalrc in den xfconf-Kanal xfce4-terminal.xml
(neuere xfce4-terminal-Versionen/Mint lesen diesen Kanal und ueberschreiben sonst terminalrc)."""
import re, sys
import xml.etree.ElementTree as ET

rc_path, xml_path = sys.argv[1], sys.argv[2]
rc = {}
for ln in open(rc_path, encoding="utf-8"):
    if "=" in ln and not ln.startswith("["):
        k, v = ln.rstrip("\n").split("=", 1); rc[k] = v

norm = lambda s: re.sub(r"[-_]", "", s).lower()
kebab = lambda k: re.sub(r"(?<!^)(?=[A-Z])", "-", k).lower()
tree = ET.parse(xml_path); root = tree.getroot()
props = {p.get("name"): p for p in root.findall("property")}
byn = {norm(n): p for n, p in props.items()}

def setval(p, key, val):
    t = p.get("type", "string")
    if t == "array":
        for c in list(p): p.remove(c)
        for part in val.split(";"):
            ET.SubElement(p, "value", type="string", value=part)
    elif t == "bool": p.set("value", "true" if val.upper() == "TRUE" else "false")
    elif t in ("int", "uint"):
        try: p.set("value", str(int(float(val))))
        except ValueError: print(f"  uebersprungen (Typ {t}): {key}")
    elif t == "double": p.set("value", str(float(val)))
    else: p.set("type", "string"); p.set("value", val)

n = 0
for key, val in rc.items():
    p = byn.get(norm(key))
    if p is None:
        t = "bool" if val in ("TRUE", "FALSE") else ("double" if re.fullmatch(r"\d+\.\d+", val) else "string")
        p = ET.SubElement(root, "property", name=kebab(key), type=t, value=val)
    setval(p, key, val); n += 1
tree.write(xml_path, encoding="UTF-8", xml_declaration=True)
print(f"xfce4-terminal.xml: {n} Werte uebertragen")
