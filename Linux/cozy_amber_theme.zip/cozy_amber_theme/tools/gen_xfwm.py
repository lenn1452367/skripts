#!/usr/bin/env python3
"""Erzeugt das xfwm4-Fensterrahmen-Theme: Titelleiste #2a1b12, 8px-Rundung,
Drei kreisfoermige, dezent gluehende Punkte (keine Symbole)."""
import os, sys
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from render import context

S = 4  # Supersampling
ctx = context()
OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)

def rgb(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def mix(a, b, t): return tuple(round(a[i] * (1 - t) + b[i] * t) for i in range(3))

TH = int(ctx["TITLEBAR_HEIGHT"]); R = int(ctx["WINDOW_RADIUS"])
BS = 4          # seitliche Rahmenbreite
BB = R          # unterer Rahmen = Eckradius, damit die Rundung vollstaendig ist
BAR, FG, DIM = rgb(ctx["BG_BAR"]), rgb(ctx["FG"]), rgb(ctx["FG_DIM"])
STATES = ("active", "inactive")

def save(img, name): img.save(os.path.join(OUT, name + ".png"))
def solid(w, h): return Image.new("RGBA", (w, h), BAR + (255,))

def corner(w, h, where):
    W, H, r = w * S, h * S, R * S
    m = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(m)
    box = {"tl": [0, 0, W + 2 * r, H + 2 * r], "tr": [-2 * r, 0, W, H + 2 * r],
           "bl": [0, -2 * r, W + 2 * r, H], "br": [-2 * r, -2 * r, W, H]}[where]
    d.rounded_rectangle(box, radius=r, fill=255)
    m = m.resize((w, h), Image.LANCZOS)
    img = solid(w, h); img.putalpha(m)
    return img

def button(color, state):
    W, H = 20, TH
    big = Image.new("RGBA", (W * S, H * S), BAR + (255,))
    cx, cy, r = W * S / 2, H * S / 2, 6 * S
    ga = {"active": 110, "prelight": 175, "pressed": 70, "inactive": 0}[state]
    gr = r * (1.25 if state == "pressed" else 1.55)
    glow = Image.new("RGBA", big.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([cx - gr, cy - gr, cx + gr, cy + gr], fill=color + (ga,))
    big = Image.alpha_composite(big, glow.filter(ImageFilter.GaussianBlur(3 * S)))
    col = {"active": color, "prelight": mix(color, FG, .22),
           "pressed": mix(color, BAR, .30), "inactive": mix(color, BAR, .55)}[state]
    ImageDraw.Draw(big).ellipse([cx - r, cy - r, cx + r, cy + r], fill=col + (255,))
    return big.resize((W, H), Image.LANCZOS)

# --- Rahmenteile -----------------------------------------------------------------
for st in STATES:
    for i in range(1, 6):
        save(solid(4, TH), f"title-{i}-{st}")
    save(corner(R, TH, "tl"), f"top-left-{st}")
    save(corner(R, TH, "tr"), f"top-right-{st}")
    save(solid(BS, 4), f"left-{st}")
    save(solid(BS, 4), f"right-{st}")
    save(solid(4, BB), f"bottom-{st}")
    save(corner(R, BB, "bl"), f"bottom-left-{st}")
    save(corner(R, BB, "br"), f"bottom-right-{st}")

# --- Knoepfe ---------------------------------------------------------------------
gold = rgb(ctx["ICON_GOLD"])
buttons = {"close": rgb(ctx["BTN_CLOSE"]), "hide": rgb(ctx["BTN_MIN"]),
           "maximize": rgb(ctx["BTN_MAX"]), "maximize-toggled": rgb(ctx["BTN_MAX"]),
           "menu": gold, "shade": gold, "shade-toggled": gold, "stick": gold, "stick-toggled": gold}
for name, col in buttons.items():
    for state in ("active", "inactive", "prelight", "pressed"):
        save(button(col, state), f"{name}-{state}")

# --- themerc ---------------------------------------------------------------------
c = lambda k: ctx[k]
lines = [
    f"active_text_color={c('FG')}", f"inactive_text_color={c('FG_DIM')}",
    f"active_text_shadow_color={c('BG_BAR')}", f"inactive_text_shadow_color={c('BG_BAR')}",
    "title_shadow_active=false", "title_shadow_inactive=false",
    f"active_border_color={c('BG_BAR')}", f"inactive_border_color={c('BG_BAR')}",
]
for st in STATES:
    for n in ("color_1", "color_2", "hilight_1", "hilight_2", "shadow_1", "shadow_2", "mid_1", "mid_2"):
        lines.append(f"{st}_{n}={c('BG_BAR')}")
lines += ["button_offset=8", "button_spacing=2", "full_width_title=true", "maximized_offset=0",
          "title_vertical_offset_active=0", "title_vertical_offset_inactive=0", "show_app_icon=false"]
with open(os.path.join(OUT, "themerc"), "w") as fh:
    fh.write("\n".join(lines) + "\n")
print(f"xfwm4-Theme: {OUT}")
