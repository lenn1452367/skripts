#!/usr/bin/env python3
"""Prozedurales Walnussholz-Wallpaper mit weichem, warmem Eck-Bokeh.
Alle Farben werden aus der Palette abgeleitet (BG_DEEP, ACCENT) -> garantiert warm."""
import argparse, math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from render import context

def hex_rgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32) / 255.0

def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)

def value_noise(rng, h, w, sy, sx):
    """Glattes (bikubisch hochskaliertes) Rauschen, anisotrop: sy vertikal, sx horizontal."""
    lh = int(math.ceil(h / sy)) + 3
    lw = int(math.ceil(w / sx)) + 3
    small = rng.random((lh, lw), dtype=np.float32)
    img = Image.fromarray(small).resize((int(math.ceil(lw * sx)), int(math.ceil(lh * sy))), Image.BICUBIC)
    return np.asarray(img, dtype=np.float32)[:h, :w]

def fbm(rng, h, w, scales, weights):
    acc = np.zeros((h, w), np.float32)
    for (sy, sx), wt in zip(scales, weights):
        acc += wt * value_noise(rng, h, w, max(sy, 1.0), max(sx, 1.0))
    return acc / sum(weights)

def build(w, h, seed, ctx):
    rng = np.random.default_rng(seed)
    deep, amber = hex_rgb(ctx["BG_DEEP"]), hex_rgb(ctx["ACCENT"])
    k = h / 2160.0

    # --- Maserung: Jahresringe, verzerrt durch niederfrequentes Rauschen -----------
    warp = fbm(rng, h, w, [(500 * k, 1200 * k), (180 * k, 420 * k), (70 * k, 160 * k)], [1, .5, .22])
    warp = (warp - warp.mean()) * 1.5
    yy = np.arange(h, dtype=np.float32)[:, None]
    period = 46 * k
    ring = 0.5 + 0.5 * np.sin(2 * np.pi * (yy / period + warp * 1.6))
    ring = np.power(ring, 1.3)
    ring2 = 0.5 + 0.5 * np.sin(2 * np.pi * (yy / (period * 3.1) + warp * 1.4))
    fiber = fbm(rng, h, w, [(1.6 * k, 140 * k), (3.5 * k, 300 * k), (8 * k, 600 * k)], [1, .7, .15])
    blotch = fbm(rng, h, w, [(120 * k, 700 * k), (50 * k, 260 * k)], [1, .5])
    pores = smoothstep(.80, .97, value_noise(rng, h, w, max(1.2 * k, 1.0), 22 * k))

    tone = .26 * ring + .16 * ring2 + .42 * fiber + .16 * blotch
    lo, hi = np.percentile(tone, 1), np.percentile(tone, 99)
    tone = np.clip((tone - lo) / (hi - lo), 0, 1) * (1 - .35 * pores)

    # --- Farbrampe aus der Palette (dunkles Walnuss) --------------------------------
    stops = np.array([0.0, .35, .7, 1.0])
    cols = np.stack([deep * .55, deep * .85, deep + (amber - deep) * .07, deep + (amber - deep) * .15])
    rgb = np.empty((h, w, 3), np.float32)
    for c in range(3):
        rgb[..., c] = np.interp(tone, stops, cols[:, c])

    # --- Plastizitaet: Streiflicht von oben links aus der Maserung -----------------
    gy, gx = np.gradient(tone)
    shade = np.clip(1 + 2.4 * (-gy * .8 - gx * .3), .85, 1.15)
    rgb *= shade[..., None]

    # --- Warm-Bokeh aus den aeusseren Ecken (nur weiche Verlaeufe, keine Kanten) ----
    diag = math.hypot(w, h)
    xs = np.arange(w, dtype=np.float32)[None, :]
    ys = np.arange(h, dtype=np.float32)[:, None]
    G = np.zeros((h, w), np.float32)
    for cx, cy, strength in ((0, 0, .90), (w, h, .75), (w, 0, .50), (0, h, .40)):
        d2 = ((xs - cx) ** 2 + (ys - cy) ** 2) / (.26 * diag) ** 2
        G += strength * np.exp(-d2 * 2.4)

    layer = Image.new("L", (w, h), 0)
    dr = ImageDraw.Draw(layer)
    corners = [(0, 0), (w, 0), (0, h), (w, h)]
    for _ in range(16):
        cx, cy = corners[rng.integers(0, 4)]
        px = abs(cx - rng.random() * .34 * w)
        py = abs(cy - rng.random() * .34 * h)
        r = rng.uniform(.018, .060) * h
        v = int(rng.uniform(.30, .75) * 255)
        dr.ellipse([px - r, py - r, px + r, py + r], fill=v)
    layer = layer.filter(ImageFilter.GaussianBlur(max(6, .016 * h)))   # stark weichgezeichnet
    G += (np.asarray(layer, dtype=np.float32) / 255.0) * .22

    out = rgb * (1 + 1.2 * G[..., None]) + G[..., None] * amber * .30
    # --- Anti-Banding-Dither (gleich fuer alle Kanaele -> Farbton bleibt warm) ------
    out += rng.normal(0, .6 / 255, (h, w, 1)).astype(np.float32)
    return Image.fromarray((np.clip(out, 0, 1) * 255 + .5).astype(np.uint8), "RGB")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--width", type=int); ap.add_argument("--height", type=int)
    ap.add_argument("--seed", type=int); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    ctx = context()
    w = a.width or int(ctx["WALLPAPER_WIDTH"]); h = a.height or int(ctx["WALLPAPER_HEIGHT"])
    seed = a.seed if a.seed is not None else int(ctx["WALLPAPER_SEED"])
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    build(w, h, seed, ctx).save(a.out, compress_level=6)
    print(f"Wallpaper: {a.out} ({w}x{h})")
