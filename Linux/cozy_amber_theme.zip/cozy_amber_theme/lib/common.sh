#!/usr/bin/env bash
# lib/common.sh – gemeinsame Helfer; wird von jedem Stage-Skript gesourct.
if [[ $EUID -eq 0 && -z "${COZY_ALLOW_ROOT:-}" ]]; then
  echo "✗ Nicht mit sudo/als root starten! Die Einstellungen wuerden in das Home von root geschrieben." >&2
  echo "  Richtig: als normaler Benutzer ./install.sh ausfuehren (Stage 10 fragt selbst per sudo nach)." >&2
  echo "  Falls bereits mit sudo installiert: sudo COZY_ALLOW_ROOT=1 ./uninstall.sh" >&2
  exit 1
fi
COZY_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export COZY_ROOT

set -a
# shellcheck disable=SC1091
. "$COZY_ROOT/config/palette.conf"
# shellcheck disable=SC1091
. "$COZY_ROOT/config/settings.conf"
set +a

export THEME_DIR="$HOME/.themes/$GTK_THEME_NAME"
export ICON_DIR="$HOME/.local/share/icons/$ICON_THEME_NAME"
export WALLPAPER_FILE="$HOME/.local/share/backgrounds/cozy-amber-walnut.png"
export STATE_DIR="$HOME/.local/share/cozy-amber"
export BACKUP_DIR="$STATE_DIR/original-backup"
export CFG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}"
export XFCONF_XML_DIR="$CFG_DIR/xfce4/xfconf/xfce-perchannel-xml"
export COZY_SHELL_DIR="$CFG_DIR/cozy-amber"

log()  { printf '\033[38;2;232;141;79m▸\033[0m %s\n' "$*"; }
ok()   { printf '\033[38;2;138;154;104m✓\033[0m %s\n' "$*"; }
warn() { printf '\033[38;2;212;163;89m!\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[38;2;192;86;75m✗\033[0m %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

# Sicherung: jede Datei wird nur beim ERSTEN Mal gesichert (= echter Originalzustand).
backup() {
  local p="$1" rel; rel="${p#"$HOME"/}"
  mkdir -p "$BACKUP_DIR/files"
  touch "$BACKUP_DIR/MANIFEST"
  grep -qxF "M $rel" "$BACKUP_DIR/MANIFEST" && return 0
  grep -qxF "C $rel" "$BACKUP_DIR/MANIFEST" && return 0
  if [[ -e "$p" || -L "$p" ]]; then
    mkdir -p "$BACKUP_DIR/files/$(dirname "$rel")"
    cp -a "$p" "$BACKUP_DIR/files/$rel"
    echo "M $rel" >> "$BACKUP_DIR/MANIFEST"
  else
    echo "C $rel" >> "$BACKUP_DIR/MANIFEST"
  fi
}

render() { python3 "$COZY_ROOT/tools/render.py" "$1" "$2"; }
# install_rendered <template relativ zu templates/> <Ziel>
install_rendered() {
  local tpl="$COZY_ROOT/templates/$1" dest="$2"
  backup "$dest"
  mkdir -p "$(dirname "$dest")"
  render "$tpl" "$dest"
}

has_session() { [[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]] && have xfconf-query; }

xfq() {
  have xfconf-query || { warn "xfconf-query fehlt"; return 1; }
  if [[ -n "${DBUS_SESSION_BUS_ADDRESS:-}" ]]; then xfconf-query "$@"
  elif have dbus-run-session; then dbus-run-session -- xfconf-query "$@"
  else xfconf-query "$@"; fi
}
# xf_set <channel> <property> <type> <value>
xf_set() {
  local ch="$1" prop="$2" type="$3" val="$4"
  xfq -c "$ch" -p "$prop" -n -t "$type" -s "$val" >/dev/null 2>&1 && return 0
  xfq -c "$ch" -p "$prop" -r >/dev/null 2>&1 || true
  xfq -c "$ch" -p "$prop" -n -t "$type" -s "$val" >/dev/null 2>&1 || warn "xfconf: $ch $prop konnte nicht gesetzt werden"
}

# Schrift-Auswahl: erste installierte Familie aus der Kandidatenliste
pick_font() {
  local list="$1" f fams arr
  have fc-list || { echo "${list%%|*}"; return; }
  fams="$(fc-list : family 2>/dev/null | tr ',' '\n' | sed 's/^ *//')"
  IFS='|' read -ra arr <<<"$list"
  for f in "${arr[@]}"; do
    if grep -qixF "$f" <<<"$fams"; then echo "$f"; return; fi
  done
  echo "${arr[0]}"
}
resolve_fonts() {
  UI_FONT_FAMILY="$(pick_font "$UI_FONT_CANDIDATES")"
  MONO_FONT_FAMILY="$(pick_font "$MONO_FONT_CANDIDATES")"
  export UI_FONT_FAMILY MONO_FONT_FAMILY
  export UI_FONT="$UI_FONT_FAMILY $UI_FONT_SIZE"
  export UI_FONT_MEDIUM="$UI_FONT_FAMILY Medium $UI_FONT_SIZE"
  export MONO_FONT="$MONO_FONT_FAMILY $MONO_FONT_SIZE"
}
resolve_fonts
