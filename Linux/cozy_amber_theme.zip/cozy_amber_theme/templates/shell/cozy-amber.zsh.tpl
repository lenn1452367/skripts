# Cozy Amber – zsh-Prompt (24-Bit-Farben, nur warme Toene)
[[ -o interactive ]] || return 0
source "$HOME/.config/cozy-amber/colors.sh"
alias ls='ls --color=auto'; alias grep='grep --color=auto'; alias diff='diff --color=auto'
autoload -Uz vcs_info
zstyle ':vcs_info:git:*' formats ' %F{{{FOREST}}}(%b%f%F{{{WARN}}}%u%c%f%F{{{FOREST}}})%f'
zstyle ':vcs_info:git:*' check-for-changes true
zstyle ':vcs_info:git:*' unstagedstr '*'
zstyle ':vcs_info:git:*' stagedstr '+'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
precmd() { vcs_info }
setopt prompt_subst
PROMPT='%F{{{FG_DIM}}}%n@%m %F{{{TERRACOTTA}}}%~%f${vcs_info_msg_0_}%(?..%F{{{ERROR}}} ✗ %?%f) %B%F{{{ACCENT}}}❯%f%b '
