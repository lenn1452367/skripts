# Cozy Amber – bash-Prompt (24-Bit-Farben, nur warme Toene)
[[ $- == *i* ]] || return 0
. "$HOME/.config/cozy-amber/colors.sh"
alias ls='ls --color=auto'; alias grep='grep --color=auto'; alias diff='diff --color=auto'

_ca() { printf '\[\e[%sm\]' "$1"; }
__cozy_prompt() {
  local rc=$?
  local R; R="$(printf '\[\e[0m\]')"
  local git="" st=""
  if command -v git >/dev/null 2>&1 && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    local br dirty=""
    br="$(git symbolic-ref --short -q HEAD 2>/dev/null || git rev-parse --short HEAD 2>/dev/null)"
    [[ -n "$(git status --porcelain 2>/dev/null | head -n1)" ]] && dirty="$(_ca "$CA_GOLD")*"
    git=" $(_ca "$CA_GREEN")(${br}${dirty}$(_ca "$CA_GREEN"))"
  fi
  (( rc != 0 )) && st=" $(_ca "$CA_RED")✗ ${rc}"
  PS1="$(_ca "$CA_DIM")\u@\h $(_ca "$CA_COPPER")\w${git}${st} $(_ca "1;$CA_AMBER")❯${R} "
}
case ";${PROMPT_COMMAND:-};" in *";__cozy_prompt;"*) ;; *) PROMPT_COMMAND="__cozy_prompt${PROMPT_COMMAND:+;$PROMPT_COMMAND}" ;; esac
