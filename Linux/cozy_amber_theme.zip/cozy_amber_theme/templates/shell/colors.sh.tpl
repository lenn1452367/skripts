# Cozy Amber – Terminalfarben (24-Bit). Von bash und zsh gesourct.
# Pfade/Ordner: Kupfer/Terrakotta · Erfolg/Git: Waldgruen · Warnung: Matt-Gold
# Fehler: Ziegelrot · Inaktiv/Sekundaer: Sand/Khaki · Text: Creme
export CA_FG='38;2;{{FG_R}};{{FG_G}};{{FG_B}}'
export CA_DIM='38;2;{{FG_DIM_R}};{{FG_DIM_G}};{{FG_DIM_B}}'
export CA_COPPER='38;2;{{TERRACOTTA_R}};{{TERRACOTTA_G}};{{TERRACOTTA_B}}'
export CA_GREEN='38;2;{{FOREST_R}};{{FOREST_G}};{{FOREST_B}}'
export CA_GOLD='38;2;{{WARN_R}};{{WARN_G}};{{WARN_B}}'
export CA_RED='38;2;{{ERROR_R}};{{ERROR_G}};{{ERROR_B}}'
export CA_AMBER='38;2;{{ACCENT_R}};{{ACCENT_G}};{{ACCENT_B}}'

export LS_COLORS="rs=0:fi=${CA_FG}:no=${CA_FG}:di=1;${CA_COPPER}:tw=1;${CA_COPPER}:ow=1;${CA_COPPER}:st=1;${CA_COPPER}:ln=${CA_GOLD}:mh=${CA_DIM}:pi=${CA_GOLD}:so=${CA_GOLD}:do=${CA_GOLD}:bd=${CA_GOLD}:cd=${CA_GOLD}:or=${CA_RED}:mi=${CA_RED}:su=${CA_RED}:sg=${CA_RED}:ca=${CA_RED}:ex=${CA_GREEN}:*.tar=${CA_GOLD}:*.gz=${CA_GOLD}:*.zip=${CA_GOLD}:*.xz=${CA_GOLD}:*.7z=${CA_GOLD}:*.deb=${CA_GOLD}:*.rpm=${CA_GOLD}:*.jpg=${CA_AMBER}:*.jpeg=${CA_AMBER}:*.png=${CA_AMBER}:*.svg=${CA_AMBER}:*.gif=${CA_AMBER}:*.mp3=${CA_AMBER}:*.flac=${CA_AMBER}:*.mp4=${CA_AMBER}:*.mkv=${CA_AMBER}:*~=${CA_DIM}:*.bak=${CA_DIM}:*.log=${CA_DIM}:*.o=${CA_DIM}"
export EZA_COLORS="$LS_COLORS"
export CLICOLOR=1
export GREP_COLORS="mt=1;${CA_AMBER}:fn=${CA_COPPER}:ln=${CA_DIM}:se=${CA_DIM}"
export GCC_COLORS="error=1;${CA_RED}:warning=1;${CA_GOLD}:note=${CA_DIM}:caret=${CA_AMBER}:locus=${CA_COPPER}:quote=${CA_FG}"
export LESS_TERMCAP_md=$'\e[1;38;2;{{ACCENT_R}};{{ACCENT_G}};{{ACCENT_B}}m'
export LESS_TERMCAP_us=$'\e[4;38;2;{{WARN_R}};{{WARN_G}};{{WARN_B}}m'
export LESS_TERMCAP_so=$'\e[48;2;{{SEL_BG_R}};{{SEL_BG_G}};{{SEL_BG_B}};38;2;{{FG_R}};{{FG_G}};{{FG_B}}m'
export LESS_TERMCAP_me=$'\e[0m'
export LESS_TERMCAP_ue=$'\e[0m'
export LESS_TERMCAP_se=$'\e[0m'
