gtk-theme-name="{{GTK_THEME_NAME}}"
gtk-icon-theme-name="{{ICON_THEME_NAME}}"
gtk-font-name="{{UI_FONT}}"
gtk-cursor-blink=1
