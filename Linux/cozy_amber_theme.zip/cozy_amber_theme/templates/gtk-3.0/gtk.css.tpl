/* Cozy Amber & Frosted Glass – GTK 3 (generiert aus templates/gtk-3.0/gtk.css.tpl) */
@import url("resource:///org/gtk/libgtk/theme/Adwaita/gtk-contained-dark.css");

@define-color bg_deep {{BG_DEEP}};
@define-color bg_bar {{BG_BAR}};
@define-color accent {{ACCENT}};
@define-color fg {{FG}};
@define-color fg_dim {{FG_DIM}};
@define-color icon_gold {{ICON_GOLD}};
@define-color sel_bg {{SEL_BG}};
@define-color btn_close {{BTN_CLOSE}};
@define-color btn_min {{BTN_MIN}};
@define-color btn_max {{BTN_MAX}};
@define-color forest {{FOREST}};
@define-color terracotta {{TERRACOTTA}};
@define-color hover mix(@bg_bar, @accent, 0.22);
@define-color pressed mix(@bg_bar, @accent, 0.38);
@define-color line mix(@bg_bar, @fg_dim, 0.28);

/* Adwaita-Farbnamen -> Palette (ueberschreibt alle blauen/grauen Standardwerte) */
@define-color theme_bg_color @bg_deep;
@define-color theme_fg_color @fg;
@define-color theme_base_color @bg_deep;
@define-color theme_text_color @fg;
@define-color theme_selected_bg_color @sel_bg;
@define-color theme_selected_fg_color @fg;
@define-color theme_unfocused_bg_color @bg_deep;
@define-color theme_unfocused_fg_color @fg_dim;
@define-color theme_unfocused_base_color @bg_deep;
@define-color theme_unfocused_text_color @fg_dim;
@define-color theme_unfocused_selected_bg_color @sel_bg;
@define-color theme_unfocused_selected_fg_color @fg;
@define-color insensitive_bg_color mix(@bg_bar, @bg_deep, 0.5);
@define-color insensitive_fg_color @fg_dim;
@define-color insensitive_base_color @bg_deep;
@define-color unfocused_insensitive_color @fg_dim;
@define-color borders @line;
@define-color unfocused_borders @line;
@define-color warning_color {{WARN}};
@define-color error_color {{ERROR}};
@define-color success_color @forest;
@define-color link_color @accent;
@define-color link_visited_color @terracotta;
@define-color content_view_bg @bg_deep;
@define-color text_view_bg @bg_deep;
@define-color placeholder_text_color @fg_dim;
@define-color tooltip_bg_color @bg_bar;
@define-color tooltip_fg_color @fg;
@define-color tooltip_border_color @accent;
@define-color osd_bg @bg_bar;
@define-color osd_fg @fg;
@define-color osd_border @line;
@define-color wm_title @fg;
@define-color wm_unfocused_title @fg_dim;
@define-color wm_bg @bg_bar;
@define-color wm_border @bg_bar;

/* ---------- Basis ---------- */
window, dialog, .background { background-color: @bg_deep; color: @fg; }
*:disabled, label:disabled { color: @fg_dim; }
*:selected, selection, label selection, entry selection, textview text selection {
  background-color: @sel_bg; color: @fg; }
*:focus { outline-color: alpha(@accent, 0.55); }
separator { background-color: @line; min-height: 1px; min-width: 1px; }
frame > border, .frame { border-color: @line; }
link, *:link { color: @accent; }
*:visited { color: @terracotta; }

/* ---------- Fensterrahmen: Rundung 8px + weicher Schatten ---------- */
decoration {
  border-radius: {{WINDOW_RADIUS}}px;
  box-shadow: {{SHADOW_CSS}}, 0 0 0 1px @bg_bar;
  margin: 30px; border: none; }
decoration:backdrop { box-shadow: 0 6px 24px 0 rgba(0, 0, 0, 0.35), 0 0 0 1px @bg_bar; }
window.maximized decoration, window.fullscreen decoration, window.tiled decoration,
window.ssd decoration, .ssd decoration, .maximized decoration, .tiled decoration {
  border-radius: 0; box-shadow: none; margin: 0; }

/* ---------- Titelleiste + Drei-Punkte-Knoepfe ---------- */
headerbar, .titlebar, headerbar:backdrop, .titlebar:backdrop {
  background-color: @bg_bar; background-image: none; color: @fg;
  border: none; box-shadow: none; border-radius: {{WINDOW_RADIUS}}px {{WINDOW_RADIUS}}px 0 0;
  min-height: {{TITLEBAR_HEIGHT}}px; }
headerbar:backdrop, .titlebar:backdrop { color: @fg_dim; }
headerbar .title, .titlebar .title { color: @fg; font-weight: 500; }
headerbar .subtitle { color: @fg_dim; }
headerbar button.titlebutton, .titlebar button.titlebutton {
  min-width: 14px; min-height: 14px; padding: 0; margin: 0 5px; border-radius: 50%;
  border: none; background-image: none; text-shadow: none; -gtk-icon-shadow: none;
  box-shadow: 0 0 6px 0 alpha(@fg_dim, 0.25); }
headerbar button.titlebutton image, .titlebar button.titlebutton image { opacity: 0; }
headerbar button.titlebutton.close    { background-color: @btn_close; box-shadow: 0 0 7px 0 alpha(@btn_close, 0.55); }
headerbar button.titlebutton.minimize { background-color: @btn_min;   box-shadow: 0 0 7px 0 alpha(@btn_min, 0.55); }
headerbar button.titlebutton.maximize { background-color: @btn_max;   box-shadow: 0 0 7px 0 alpha(@btn_max, 0.55); }
headerbar button.titlebutton.close:hover    { background-color: mix(@btn_close, @fg, 0.2); }
headerbar button.titlebutton.minimize:hover { background-color: mix(@btn_min, @fg, 0.2); }
headerbar button.titlebutton.maximize:hover { background-color: mix(@btn_max, @fg, 0.2); }
headerbar button.titlebutton:backdrop { background-color: mix(@bg_bar, @fg_dim, 0.35); box-shadow: none; }

/* ---------- Buttons ---------- */
button {
  background-color: @bg_bar; background-image: none; color: @fg;
  border: 1px solid @line; border-radius: 6px; box-shadow: none; text-shadow: none;
  -gtk-icon-shadow: none; }
button:hover { background-color: @hover; border-color: alpha(@accent, 0.6); }
button:active, button:checked { background-color: @pressed; color: @fg; border-color: @accent; }
button:disabled { background-color: mix(@bg_bar, @bg_deep, 0.5); color: @fg_dim; border-color: @line; }
button:focus { border-color: alpha(@accent, 0.8); }
button.flat, headerbar button.flat, toolbar button { background-color: transparent; border-color: transparent; }
button.flat:hover, toolbar button:hover { background-color: @hover; border-color: transparent; }
button.suggested-action { background-color: @accent; color: @bg_deep; border-color: @accent; }
button.suggested-action:hover { background-color: mix(@accent, @fg, 0.15); }
button.destructive-action { background-color: @btn_close; color: @fg; border-color: @btn_close; }
button.destructive-action:hover { background-color: mix(@btn_close, @fg, 0.15); }
headerbar button:not(.titlebutton) { background-color: transparent; border-color: transparent; }
headerbar button:not(.titlebutton):hover { background-color: @hover; }
linkbutton > button { color: @accent; }

/* ---------- Eingabe ---------- */
entry, spinbutton, spinbutton button, combobox button, textview, textview text, .view {
  background-color: @bg_deep; background-image: none; color: @fg; caret-color: @accent; }
entry, spinbutton { border: 1px solid @line; border-radius: 6px; box-shadow: none; }
entry:focus, spinbutton:focus { border-color: @accent; box-shadow: 0 0 0 1px alpha(@accent, 0.45); }
entry:disabled { background-color: mix(@bg_bar, @bg_deep, 0.5); }
entry image, entry progress { color: @fg_dim; }
entry progress { background-color: @accent; }
spinbutton button { border: none; border-radius: 0; }
spinbutton button:hover { background-color: @hover; }

/* ---------- Listen, Tabellen, Dateiansicht (Auswahl: #5e3821 + Bernstein-Rand) ---------- */
.view, iconview, treeview.view, list, row, textview text { background-color: @bg_deep; color: @fg; }
treeview.view header button { background-color: @bg_bar; color: @fg; border-radius: 0; border-color: @line; }
.view:selected, .view:selected:focus, treeview.view:selected, treeview.view:selected:focus,
iconview:selected, iconview .cell:selected, row:selected, flowboxchild:selected, .view .cell:selected {
  background-color: @sel_bg; color: @fg; box-shadow: inset 0 0 0 1px @accent; border-radius: 6px; }
row:hover, treeview.view:hover, iconview:hover, flowboxchild:hover, .view .cell:hover { background-color: @hover; }
treeview.view:hover:selected { background-color: @sel_bg; }
treeview.view.expander { color: @fg_dim; }
treeview.view.expander:hover { color: @accent; }

/* ---------- Menues & Popover ---------- */
menu, .menu, .popup, menubar, popover, popover.background, .csd.popup decoration {
  background-color: @bg_bar; color: @fg; border: 1px solid @line; border-radius: {{WINDOW_RADIUS}}px; }
menubar { border: none; border-radius: 0; }
menuitem { color: @fg; border-radius: 4px; }
menuitem:hover, menuitem:selected, modelbutton:hover { background-color: @hover; color: @fg; }
menuitem:disabled { color: @fg_dim; }
menuitem check, menuitem radio { color: @accent; }
modelbutton { color: @fg; border-radius: 4px; }
popover separator, menu separator { background-color: @line; }

/* ---------- Leisten, Seitenleisten, Thunar ---------- */
toolbar, .toolbar, .inline-toolbar, .primary-toolbar, statusbar, actionbar, .thunar toolbar {
  background-color: @bg_bar; background-image: none; color: @fg; border-color: @line; box-shadow: none; }
.sidebar, placessidebar, placessidebar list, placessidebar row, .thunar .shortcuts-pane,
.thunar .sidebar, .thunar .shortcuts-pane treeview, stacksidebar, stacksidebar list {
  background-color: @bg_bar; color: @fg; }
placessidebar row:hover, stacksidebar row:hover { background-color: @hover; }
placessidebar row:selected, stacksidebar row:selected { background-color: @sel_bg; box-shadow: inset 0 0 0 1px @accent; }
.thunar .path-bar button, pathbar button { background-color: transparent; border-color: transparent; color: @fg; }
.thunar .path-bar button:hover { background-color: @hover; }
.thunar .path-bar button:checked { background-color: @sel_bg; box-shadow: inset 0 0 0 1px @accent; }
paned > separator { background-color: @line; }
infobar, infobar.info, infobar.warning, infobar.question, infobar.error { background-color: @sel_bg; color: @fg; border: none; }

/* ---------- Reiter ---------- */
notebook { background-color: @bg_deep; }
notebook > header { background-color: @bg_bar; border-color: @line; }
notebook > header tab { background-color: transparent; color: @fg_dim; border-color: transparent; }
notebook > header tab:hover { background-color: @hover; color: @fg; }
notebook > header tab:checked { background-color: @bg_deep; color: @fg; box-shadow: inset 0 -2px @accent; }

/* ---------- Schieber, Schalter, Haken, Fortschritt ---------- */
scrollbar, scrollbar trough { background-color: transparent; border: none; }
scrollbar slider { background-color: mix(@bg_bar, @fg_dim, 0.45); border: 2px solid transparent;
  background-clip: padding-box; border-radius: 8px; min-width: 8px; min-height: 8px; }
scrollbar slider:hover { background-color: @accent; }
scrollbar button { background-color: transparent; border: none; color: @fg_dim; }
scale trough { background-color: @line; border-radius: 4px; border: none; }
scale highlight, scale fill { background-color: @accent; border-radius: 4px; }
scale slider { background-color: @fg; background-image: none; border: 1px solid @bg_bar; border-radius: 50%; }
scale slider:hover { background-color: @accent; }
switch { background-color: @bg_bar; background-image: none; border: 1px solid @line; border-radius: 14px; color: @fg; }
switch:checked { background-color: @accent; border-color: @accent; }
switch slider { background-color: @fg; background-image: none; border: none; border-radius: 50%; box-shadow: none; }
check, radio { background-color: @bg_deep; background-image: none; border: 1px solid @fg_dim; color: @bg_deep; box-shadow: none; }
check:hover, radio:hover { border-color: @accent; }
check:checked, radio:checked, check:indeterminate, radio:indeterminate { background-color: @accent; border-color: @accent; color: @bg_deep; }
progressbar trough, levelbar trough { background-color: @bg_bar; border: 1px solid @line; border-radius: 4px; }
progressbar progress, levelbar block.filled { background-color: @accent; border: none; border-radius: 4px; }
levelbar block.empty { background-color: @bg_bar; }
spinner { color: @accent; }
calendar { color: @fg; background-color: @bg_deep; }
calendar:selected { background-color: @sel_bg; box-shadow: inset 0 0 0 1px @accent; border-radius: 4px; }
calendar.highlight { color: @accent; }
tooltip, tooltip.background { background-color: @bg_bar; color: @fg; border: 1px solid alpha(@accent, 0.5); border-radius: 6px; }
tooltip * { color: @fg; background-color: transparent; }
.osd, .osd .background { background-color: alpha(@bg_bar, 0.92); color: @fg; border: 1px solid @line; }
expander arrow { color: @fg_dim; }
expander arrow:hover { color: @accent; }
colorswatch, filechooser placessidebar { border-color: @line; }

/* ---------- Xfce-Panel: Glas #2a1b12 @ 75 %, Glühfaden-Linie, goldene Icons ---------- */
.xfce4-panel.background, #XfcePanelWindow {
  background-color: rgba({{BG_BAR_RGB}}, {{PANEL_OPACITY}}); background-image: none;
  border: none; border-bottom: 1px solid @accent; border-radius: 0; box-shadow: none; }
.xfce4-panel button, .xfce4-panel button:hover, .xfce4-panel button:active, .xfce4-panel button:checked {
  background-image: none; border: none; box-shadow: none; border-radius: 6px;
  padding: 0 6px; min-height: 0; min-width: 0; color: @icon_gold; }
.xfce4-panel button { background-color: transparent; }
.xfce4-panel button:hover { background-color: alpha(@accent, 0.22); }
.xfce4-panel button:active, .xfce4-panel button:checked { background-color: alpha(@accent, 0.36); }
.xfce4-panel image, .xfce4-panel button image { -gtk-icon-style: symbolic; color: @icon_gold; }
.xfce4-panel label, .xfce4-panel button label { color: @fg; font-weight: 500; }
.xfce4-panel separator { background-color: transparent; }

/* ---------- Benachrichtigungen ---------- */
#XfceNotifyWindow, window#XfceNotifyWindow {
  background-color: @bg_bar; color: @fg; border: 1px solid @accent; border-radius: {{WINDOW_RADIUS}}px; }
#XfceNotifyWindow label { color: @fg; }
#XfceNotifyWindow progressbar progress { background-color: @accent; }

/* ---------- Sanfte Hover-Animationen (ca. 150 ms "Glühbirne dimmt hoch") ---------- */
button, menuitem, modelbutton, row, treeview.view, iconview, flowboxchild, notebook > header tab,
entry, spinbutton, scale slider, switch, check, radio, scrollbar slider, placessidebar row,
.xfce4-panel button, headerbar button.titlebutton, tooltip, .thunar .path-bar button {
  transition: background-color {{HOVER_FADE_MS}}ms ease-in-out, color {{HOVER_FADE_MS}}ms ease-in-out,
              border-color {{HOVER_FADE_MS}}ms ease-in-out, box-shadow {{HOVER_FADE_MS}}ms ease-in-out,
              opacity {{HOVER_FADE_MS}}ms ease-in-out; }
