[color]
	ui = auto
[color "status"]
	added = {{FOREST}}
	changed = {{WARN}}
	untracked = {{FG_DIM}}
	branch = {{ACCENT}}
	nobranch = {{ERROR}}
	unmerged = {{ERROR}}
	header = {{FG_DIM}}
[color "branch"]
	current = {{ACCENT}}
	local = {{FG}}
	remote = {{FOREST}}
	upstream = {{TERRACOTTA}}
[color "diff"]
	meta = {{FG_DIM}}
	frag = {{TERRACOTTA}}
	old = {{ERROR}}
	new = {{FOREST}}
	commit = {{WARN}}
[color "decorate"]
	branch = {{FOREST}}
	remoteBranch = {{TERRACOTTA}}
	tag = {{WARN}}
	HEAD = {{ACCENT}}
