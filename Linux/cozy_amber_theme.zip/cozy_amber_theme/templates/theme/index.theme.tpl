[Desktop Entry]
Type=X-GNOME-Metatheme
Name={{GTK_THEME_NAME}}
Comment=Cozy Amber & Frosted Glass – warm, organic, eye-friendly
Encoding=UTF-8

[X-GNOME-Metatheme]
GtkTheme={{GTK_THEME_NAME}}
MetacityTheme={{GTK_THEME_NAME}}
IconTheme={{ICON_THEME_NAME}}
ButtonLayout=close,minimize,maximize:
