# Cozy Amber – GTK 2 (Legacy-Anwendungen)
gtk-color-scheme = "bg_color:{{BG_DEEP}}\nfg_color:{{FG}}\nbase_color:{{BG_DEEP}}\ntext_color:{{FG}}\nselected_bg_color:{{SEL_BG}}\nselected_fg_color:{{FG}}\ntooltip_bg_color:{{BG_BAR}}\ntooltip_fg_color:{{FG}}"
gtk-cursor-blink = 1
gtk-cursor-blink-time = 1200

style "cozy" {
  bg[NORMAL]       = "{{BG_DEEP}}"
  bg[PRELIGHT]     = "{{SEL_BG}}"
  bg[ACTIVE]       = "{{SEL_BG}}"
  bg[SELECTED]     = "{{SEL_BG}}"
  bg[INSENSITIVE]  = "{{BG_BAR}}"
  fg[NORMAL]       = "{{FG}}"
  fg[PRELIGHT]     = "{{FG}}"
  fg[ACTIVE]       = "{{FG}}"
  fg[SELECTED]     = "{{FG}}"
  fg[INSENSITIVE]  = "{{FG_DIM}}"
  base[NORMAL]     = "{{BG_DEEP}}"
  base[PRELIGHT]   = "{{BG_BAR}}"
  base[ACTIVE]     = "{{SEL_BG}}"
  base[SELECTED]   = "{{SEL_BG}}"
  base[INSENSITIVE]= "{{BG_BAR}}"
  text[NORMAL]     = "{{FG}}"
  text[PRELIGHT]   = "{{FG}}"
  text[ACTIVE]     = "{{FG}}"
  text[SELECTED]   = "{{FG}}"
  text[INSENSITIVE]= "{{FG_DIM}}"
}
style "cozy-bar" = "cozy" {
  bg[NORMAL] = "{{BG_BAR}}"
}
class "GtkWidget"  style "cozy"
class "GtkMenuBar" style "cozy-bar"
class "GtkToolbar" style "cozy-bar"
class "GtkMenu"    style "cozy-bar"
