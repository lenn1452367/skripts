#!/usr/bin/env bash
# Stage 60: xfconf – Erscheinungsbild, Fensterverwaltung/Compositor, Desktop-Hintergrund
set -euo pipefail
. "$(dirname "$0")/../lib/common.sh"
have xfconf-query || { warn "xfconf-query fehlt – Stage uebersprungen"; exit 0; }

for ch in xsettings xfwm4 xfce4-desktop; do backup "$XFCONF_XML_DIR/$ch.xml"; done

# --- Erscheinungsbild (xsettings) ---------------------------------------------------
xf_set xsettings /Net/ThemeName       string "$GTK_THEME_NAME"
xf_set xsettings /Net/IconThemeName   string "$ICON_THEME_NAME"
xf_set xsettings /Gtk/FontName        string "$UI_FONT"
xf_set xsettings /Gtk/MonospaceFontName string "$MONO_FONT"
xf_set xsettings /Gtk/DecorationLayout string "close,minimize,maximize:"
xf_set xsettings /Net/CursorBlink     bool   true
xf_set xsettings /Net/CursorBlinkTime int    1200
xf_set xsettings /Xft/Antialias       int    1
xf_set xsettings /Xft/HintStyle       string hintslight

# --- Fensterverwaltung: nur der xfwm4-eigene Compositor, KEIN picom ----------------------
xf_set xfwm4 /general/theme            string "$GTK_THEME_NAME"
xf_set xfwm4 /general/title_font       string "$UI_FONT_MEDIUM"
xf_set xfwm4 /general/title_alignment  string center
xf_set xfwm4 /general/button_layout    string "CHM|"
xf_set xfwm4 /general/use_compositing  bool   true
xf_set xfwm4 /general/show_frame_shadow bool  true
xf_set xfwm4 /general/show_popup_shadow bool  true
xf_set xfwm4 /general/show_dock_shadow  bool  false
xf_set xfwm4 /general/shadow_opacity   int    75
xf_set xfwm4 /general/shadow_delta_x   int    0
xf_set xfwm4 /general/shadow_delta_y   int    8
for k in frame_opacity inactive_opacity move_opacity resize_opacity popup_opacity; do
  xf_set xfwm4 "/general/$k" int 100
done
xf_set xfwm4 /general/vblank_mode      string auto

if pgrep -x picom >/dev/null 2>&1; then
  warn "picom laeuft – wird beendet (Spezifikation: keine externe Compositing-Engine)"
  pkill -x picom || true
fi
for f in "$CFG_DIR"/autostart/picom*.desktop; do
  [[ -f "$f" ]] || continue
  backup "$f"; printf '\nHidden=true\n' >> "$f"; warn "Autostart deaktiviert: $f"
done

# --- Desktop-Hintergrund auf allen Monitoren ---------------------------------------------
monitors=""
have xrandr && monitors="$(xrandr --listmonitors 2>/dev/null | awk 'NR>1{print $NF}')" || true
existing="$(xfq -c xfce4-desktop -l 2>/dev/null | grep 'last-image$' || true)"
targets="$existing"
names=""
for m in $monitors; do names+=" monitor${m#monitor}"; done
for m in $names monitor0 monitorVirtual-1; do
  for ws in 0 1 2 3; do targets+=$'\n'"/backdrop/screen0/$m/workspace$ws/last-image"; done
done
while read -r prop; do
  [[ -n "$prop" ]] || continue
  base="${prop%/last-image}"
  xf_set xfce4-desktop "$prop"            string "$WALLPAPER_FILE"
  xf_set xfce4-desktop "$base/image-style" int    5
  xf_set xfce4-desktop "$base/color-style" int    0
done <<<"$(printf '%s\n' "$targets" | sort -u)"
ok "xfconf gesetzt (Theme, Compositor, Wallpaper)"
